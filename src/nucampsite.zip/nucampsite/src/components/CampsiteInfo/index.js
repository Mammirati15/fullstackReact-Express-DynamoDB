import CampsiteInfo from './CampsiteInfo'

export default CampsiteInfo 